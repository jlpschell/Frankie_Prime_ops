"""Tests for MCP Launchpad."""
