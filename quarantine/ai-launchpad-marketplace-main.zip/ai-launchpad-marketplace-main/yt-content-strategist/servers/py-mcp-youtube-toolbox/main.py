def main():
    print("Hello from py-mcp-youtube-toolbox!")


if __name__ == "__main__":
    main()
